package com.zybooks.wgu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

import DialogFragments.DialogFragment_Dates;
import DialogFragments.DialogFragment_NoDates;

public class HomePage extends AppCompatActivity {

    SQLdatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        database = new SQLdatabase(this);

        String todaysDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("M/dd/yyyy"));
     
        if (database.readObjectiveassessments(todaysDate) || database.readPerformanceassessmentsDates(todaysDate)) {
            DialogFragment_Dates date = new DialogFragment_Dates();
            date.show(getSupportFragmentManager(), "date");
        }

        else {
            DialogFragment_NoDates date = new DialogFragment_NoDates();
            date.show(getSupportFragmentManager(), "date");
        }

        if (database.readObjectiveEnddates(todaysDate) || database.readPerformanceEndDates(todaysDate)) {
            DialogFragment_Dates date = new DialogFragment_Dates();
            date.show(getSupportFragmentManager(), "date");
        }

        else {
            DialogFragment_NoDates date = new DialogFragment_NoDates();
            date.show(getSupportFragmentManager(), "date");
        }

    }

    public void termsClick(View view) {
        Intent open = new Intent(this, TermsView.class);
        startActivity(open);
    }

    public void assessmentsClick(View view) {
        Intent open = new Intent(this, AssessmentChoose.class);
        startActivity(open);
    }

    public void coursesClick(View view) {
        Intent open = new Intent(this, CoursesView.class);
        startActivity(open);
    }

    public void viewnotesClick(View view) {
        Intent VIEW = new Intent(this, NotesView.class);
        startActivity(VIEW);
    }

    public void coursesAddClick(View view) {
        Intent open = new Intent(this, CoursesAdd.class);
        startActivity(open);
    }

    public void termsAddClick(View view) {
        Intent open = new Intent(this, TermsAdd.class);
        startActivity(open);
    }
}