package com.zybooks.wgu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import DialogFragments.DialogFragment_AddCourse;
import DialogFragments.DialogFragment_Update;

public class AssessmentObjectiveUpdate extends AppCompatActivity {

    SQLdatabase database;
    int courseid;
    int assessmentid;

    EditText objectiveMulti;

    String objectiveMultiassessments;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessment_objective_update);

        database = new SQLdatabase(this);

        assessmentid =  getIntent().getIntExtra("assessmentid", assessmentid);
        courseid = getIntent().getIntExtra("courseid", courseid);
        objectiveMultiassessments = getIntent().getStringExtra("assessments");

        objectiveMulti = findViewById(R.id.objectiveMulti);

        Button objectiveSavebutton = findViewById(R.id.objectiveSavebutton);

        objectiveSavebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                objectiveMultiassessments = objectiveMulti.getText().toString();

                long count = database.updateObjectiveassessments(assessmentid, objectiveMultiassessments);

                if (count > 0 ) {

                    objectiveMulti.getText().clear();

                    DialogFragment_Update add = new DialogFragment_Update();
                    add.show(getSupportFragmentManager(), "add");
                }
            }
        });

    }
}