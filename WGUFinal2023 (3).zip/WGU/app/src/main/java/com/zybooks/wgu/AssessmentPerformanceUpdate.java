package com.zybooks.wgu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import DialogFragments.DialogFragment_AddCourse;
import DialogFragments.DialogFragment_Update;

public class AssessmentPerformanceUpdate extends AppCompatActivity {

    SQLdatabase database;
    int courseid;
    int assessmentid;

    EditText performancemulti;

    String performancemultiassessments;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessment_performance_update);

        database = new SQLdatabase(this);

        assessmentid =  getIntent().getIntExtra("assessmentid", assessmentid);
        courseid = getIntent().getIntExtra("courseid", courseid);
        performancemultiassessments = getIntent().getStringExtra("assessments");

        performancemulti = findViewById(R.id.performancemulti);
        performancemulti.setText(performancemultiassessments);

        Button performancesaveButton = findViewById(R.id.performancesaveButton);

        performancesaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                performancemultiassessments = performancemulti.getText().toString();

               long count = database.updatePerformanceassessments(assessmentid, performancemultiassessments);

              if (count > 0 ) {

                    performancemulti.getText().clear();

                    DialogFragment_Update add = new DialogFragment_Update();
                    add.show(getSupportFragmentManager(), "add");
                }
            }
        });
    }
}