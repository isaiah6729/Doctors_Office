package DialogFragments;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatDialogFragment;
import androidx.fragment.app.DialogFragment;

import com.zybooks.wgu.R;

public class DialogFragment_Delete extends DialogFragment {

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        int draw = R.drawable.baseline_emoji_people_24;

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Delete Complete");
        builder.setIcon(draw);
        builder.setMessage("You have delete this item!");
        builder.setPositiveButton("Thank You", null);
        return builder.create();
    }

}